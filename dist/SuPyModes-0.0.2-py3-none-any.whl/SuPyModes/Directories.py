import os

import SuPyModes

RootPath     = SuPyModes.__path__[0]

ZeroPath     = os.path.dirname(RootPath)
