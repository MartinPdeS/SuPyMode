
{"plots": { "index": {"x": [0,1],
                     "y": [1.4,1.46]},

           "coupling": {"x": null,
                        "y": null},

           "adiabatic": {"x": [0,1],
                         "y": [1e-4,1e-0]}
            }
}
