#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Third-party imports
import numpy
from PyFinitDiff.finite_difference_2D import FiniteDifference
from PyFinitDiff.finite_difference_2D import Boundaries
from FiberFusing.geometry import Geometry

# Local imports
from SuPyMode.superset import SuperSet
from SuPyMode.supermode import SuperMode
from SuPyMode.binary.interface_supermode import SUPERMODE  # type: ignore
from SuPyMode.binary.interface_eigensolver import EIGENSOLVER  # type: ignore
from SuPyMode.binary.interface_model_parameters import ModelParameters  # type: ignore
from SuPyMode.binary.interface_mesh import GEOMETRY
from SuPyMode.mode_label import ModeLabel


class SuPySolver(EIGENSOLVER):
    """
    A solver for computing eigenvalues and supermodes of optical fiber geometries using a C++ eigensolver.

    This class manages the eigenvalue problem for optical structures and returns computed supermodes. The solver utilizes
    a C++ backend for efficient eigenvalue computation and integrates with finite difference methods to solve for various
    boundary conditions.

    Parameters
    ----------
    geometry : Geometry or numpy.ndarray
        The refractive index geometry of the optical structure.
    tolerance : float, optional
        Absolute tolerance for the propagation constant computation (default is 1e-8).
    max_iteration : int, optional
        Maximum iterations for the C++ eigensolver (default is 10,000).
    accuracy : int, optional
        Accuracy level of the finite difference method (default is 2).
    extrapolation_order : int, optional
        Order of Taylor series used to extrapolate eigenvalues (default is 2).
    debug_mode : int, optional
        Debug output level from the C++ binding, where 0 is no output and higher values provide more detail (default is 1).
    """

    def __init__(
        self,
        geometry: Geometry,
        tolerance: float = 1e-8,
        max_iteration: int = 10_000,
        accuracy: int = 2,
        extrapolation_order: int = 2,
        debug_mode: int = 1,
    ) -> None:
        """
        Initialize the solver with the given parameters.
        """
        self.geometry = geometry
        self.debug_mode = debug_mode

        self.mesh = self.geometry.mesh

        self.coordinate_system = self.geometry.coordinate_system

        super().__init__(
            max_iteration=max_iteration,
            tolerance=tolerance,
            accuracy=accuracy,
            extrapolation_order=extrapolation_order,
        )

        self.model_parameters = ModelParameters(
            dx=self.coordinate_system.dx,
            dy=self.coordinate_system.dy,
            mesh=self.mesh,
            x_vector=self.coordinate_system.x_vector,
            y_vector=self.coordinate_system.y_vector,
            debug_mode=self.debug_mode,
        )

    def initialize_binding(
        self, n_sorted_mode: int, boundaries: Boundaries, n_added_mode: int
    ) -> None:
        """
        Initialize and configure the C++ solver binding for eigenvalue computations.

        Parameters
        ----------
        n_sorted_mode : int
            Number of modes to sort and retrieve from the solver.
        boundaries : Boundaries
            Boundary conditions for the finite difference system.
        n_added_mode : int
            Number of extra modes calculated for accuracy and reliability.

        Returns
        -------
        EigenSolver
            Configured C++ solver instance.
        """
        finit_diff_matrix = FiniteDifference(
            n_x=self.coordinate_system.nx,
            n_y=self.coordinate_system.ny,
            dx=self.coordinate_system.dx,
            dy=self.coordinate_system.dy,
            derivative=2,
            accuracy=self.accuracy,
            boundaries=boundaries,
        )

        finit_diff_matrix.construct_triplet()

        new_array = numpy.c_[
            finit_diff_matrix._triplet.array[:, 1],
            finit_diff_matrix._triplet.array[:, 0],
            finit_diff_matrix._triplet.array[:, 2],
        ]

        self._cpp_set_boundaries(
            left=boundaries.left.value.lower(),
            right=boundaries.right.value.lower(),
            top=boundaries.top.value.lower(),
            bottom=boundaries.bottom.value.lower(),
        )

        self._cpp_initialize(
            model_parameters=self.model_parameters,
            finit_matrix=new_array.T,
            n_computed_mode=n_sorted_mode + n_added_mode,
            n_sorted_mode=n_sorted_mode,
        )

        self._cpp_compute_laplacian()

    def init_superset(
        self,
        wavelength: float,
        n_step: int = 300,
        itr_initial: float = 1.0,
        itr_final: float = 0.1,
    ) -> None:
        """
        Initialize a SuperSet instance containing computed supermodes over a range of inverse taper ratios (ITR).

        Parameters
        ----------
        wavelength : float
            Wavelength for the mode computation.
        n_step : int, optional
            Number of steps for the ITR interpolation (default is 300).
        itr_initial : float, optional
            Initial ITR value (default is 1.0).
        itr_final : float, optional
            Final ITR value (default is 0.1).
        """
        self.model_parameters.initialize(
            wavelength=wavelength,
            itr_initial=itr_initial,
            itr_final=itr_final,
            n_step=n_step,
        )

        self.superset = SuperSet(
            geometry=self.geometry,
            wavelength=wavelength,
            model_parameters=self.model_parameters,
        )

    def get_supermode_labels(
        self, n_modes: int, boundaries: Boundaries, auto_label: bool
    ) -> list:
        """
        Generate labels for supermodes based on boundary conditions and whether auto-labeling is enabled.

        Parameters
        ----------
        n_modes : int
            Number of modes for which labels are needed.
        boundaries : Boundaries
            Boundary conditions that affect mode symmetries.
        auto_label : bool
            If True, automatically generates labels based on mode symmetries; otherwise, generates generic labels.

        Returns
        -------
        list
            List of labels for the supermodes.
        """
        if auto_label:
            return [
                ModeLabel(boundaries=boundaries, mode_number=n).label
                for n in range(n_modes)
            ]
        else:
            return [f"mode_{{{n}}}" for n in range(n_modes)]

    def add_modes(
        self,
        n_sorted_mode: int,
        boundaries: Boundaries,
        n_added_mode: int = 4,
        index_guess: float = 0.0,
        auto_label: bool = True,
    ) -> None:
        """
        Compute and add a specified number of supermodes to the solver's collection.

        Parameters
        ----------
        n_sorted_mode : int
            Number of modes to output and sort from the solver.
        boundaries : Boundaries
            Boundary conditions for the finite difference calculations.
        n_added_mode : int, optional
            Additional modes computed to ensure mode matching accuracy (default is 4).
        index_guess : float, optional
            Starting guess for the refractive index used in calculations (default is 0., auto-evaluated if set to 0).
        auto_label : bool, optional
            If True, enables automatic labeling of modes based on symmetry (default is True).

        Returns
        -------
        None
            This method updates the solver's internal state but does not return any value.
        """

        beta_guess = self.index_to_eigenvalue(index_guess)

        self._cpp_reset_solver()

        self.initialize_binding(
            boundaries=boundaries,
            n_added_mode=n_added_mode,
            n_sorted_mode=n_sorted_mode,
        )

        self.superset.model_parameters = self.model_parameters

        print(index_guess, beta_guess)
        self.loop_over_itr(alpha=beta_guess)

        mode_labels = self.get_supermode_labels(
            n_modes=n_sorted_mode, boundaries=boundaries, auto_label=auto_label
        )

        for binding_number, label in enumerate(mode_labels):
            supermode = SuperMode(
                parent_set=self.superset,
                binding=self._cpp_get_mode(binding_number),
                mode_number=self.mode_number,
                solver_number=self.solver_number,
                boundaries=boundaries,
                label=label,
            )

            self.superset.supermodes.append(supermode)

            setattr(self.superset, label, supermode)

            self.mode_number += 1

        self.solver_number += 1
